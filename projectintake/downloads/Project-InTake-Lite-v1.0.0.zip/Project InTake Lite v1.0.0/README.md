# Project InTake Lite

> **Version 1.0.0**

**Automatic media ingest for Adobe Premiere Pro—simple, free, and focused.**

Project InTake Lite watches one folder and automatically imports new media into
your active Premiere project. Choose a folder, click **Start Watching**, and get
back to editing.

## Features

- Watches one folder at a time.
- Checks for new media every three seconds.
- Imports supported video, audio, and still-image files automatically.
- Waits for files to finish copying before importing them.
- Places all imported media in one flat Premiere bin named
  `Project Intake Lite`.
- Prevents the same file from being imported repeatedly.
- Remembers the selected folder and imported-file history for each Premiere
  project.
- Supports macOS and Windows path handling.
- Detects likely image sequences and offers a link to Project InTake Pro.

## Requirements

| Requirement | Details |
| --- | --- |
| Adobe Premiere Pro | Version 25.6 or newer |
| Premiere project | Open a project before using the plugin |
| Installation | Adobe Creative Cloud Desktop |

## Installation

1. Quit Adobe Premiere Pro.
2. Double-click the `ProjectInTakeLite...ccx` file.
3. Follow the Adobe Creative Cloud Desktop installation prompt.
4. Reopen Premiere Pro.
5. Choose **Window → UXP Plugins → Project InTake Lite**.

Developer Mode and UXP Developer Tool are not required. Adobe may display a
warning for a privately distributed plugin; install only a package received
from a source you trust.

## Getting started

1. Open the Premiere project where you want imported media to appear.
2. Open **Window → UXP Plugins → Project InTake Lite**.
3. Click **Select Folder** and choose a folder containing incoming media.
4. Click **Start Watching**.
5. Add or copy supported media directly into the selected folder.

Project InTake Lite waits for each file to stabilize, then imports it into the
`Project Intake Lite` bin. Click **Stop Watching** whenever you want to pause
automatic ingest.

Selecting a different folder stops the current watcher and replaces the previous
selection. Click **Start Watching** again to monitor the new folder.

## What Lite does not include

Project InTake Lite is intentionally focused. It does not:

- Watch multiple folders.
- Scan subfolders.
- Mirror filesystem folders as Premiere bins.
- Import image sequences.
- Include manual Re-Ingest, advanced diagnostics, health reports, or sync
  controls.

For those workflows, use [Project InTake Pro](https://timsarquis.com/projectintake/).

## Image sequences

Lite does not import numbered image sequences as individual still images. When
it detects multiple matching frames, it skips the sequence and displays:

> Image sequence import requires Project InTake Pro

Regular still images remain supported. A filename containing a number is not
rejected unless multiple matching files appear to form a likely sequence.

## Supported media

Lite recognizes common Premiere-compatible formats, including:

- Video: MOV, MP4, MXF, MTS, M2TS, AVI, MPG, MPEG, BRAW, R3D, ARI, and CRM
- Audio: WAV, MP3, AIF, AIFF, and M4A
- Images: JPG, JPEG, PNG, TIF, TIFF, PSD, GIF, DNG, and EXR

Premiere ultimately determines whether a particular file can be imported.

## Troubleshooting

### The plugin is not listed in Premiere

- Confirm Premiere Pro is version 25.6 or newer.
- Confirm installation completed successfully in Creative Cloud Desktop.
- Restart Premiere after installation.
- Look under **Window → UXP Plugins**, not the legacy Extensions menu.

### New media has not imported

- Confirm **Stop Watching** is visible, indicating that watching is active.
- Make sure the file is directly inside the selected folder, not a subfolder.
- Allow time for the file to finish copying and remain unchanged across scans.
- Confirm the folder or external drive is still available.
- Check the compact status message below the controls.

### A file was skipped

- Unsupported files are ignored.
- Subfolder contents are intentionally ignored.
- Likely image sequences require Project InTake Pro.
- Files already imported by Lite are not imported again.

### Folder access was lost

Reconnect the drive or restore access to the selected folder. If access cannot
be restored, click **Select Folder** and choose the folder again.

## Privacy

Project InTake Lite works locally with the folder you select and the active
Premiere project. It does not upload your media. The only external link is the
user-initiated **Upgrade to Pro** action.

## Learn more

Visit [Project InTake](https://timsarquis.com/projectintake/) for product news,
support information, and Project InTake Pro.
